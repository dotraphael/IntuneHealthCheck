# Reference data

Data the rules compare against, one file per table, named by the file. A table is a **list of rows**: `FolderPackStore` reads every `*.json` here, and `packtools build` refuses a file that is not an array, so an object at the top level is invisible to the accessor written for it.

A row's columns are read through `Ref`. Where a compiled accessor exists, the columns below are the ones it reads and renaming one silently empties the rules over it. Where none exists yet, the shape is the plainest one that carries the content and the accessor settles its columns when it is written. Every accessor is total, so a table this pack does not carry, or a row it does not hold, makes a rule find nothing rather than fail.

These files carried a `_note` and an `asOf` when they were objects. An array has nowhere to put either, so both live here.

## Tables with a compiled accessor

| File | Accessor | Columns | Maintenance |
|---|---|---|---|
| `windows-builds.json` | `Ref.WindowsBuilds` | `build`, `name`, `endOfService` | As of 2026-09-01. Verify against <https://learn.microsoft.com/lifecycle/products/> before every release; the tool treats this as authoritative. Dates are the Enterprise and Education end of service, which is what an Intune managed estate runs; Home and Pro leave support a year earlier and are judged leniently here. Long term servicing builds share a build number with the twice-yearly release and are serviced far longer, which this table cannot express |
| `baselines.json` | `Ref.Baselines` | `name`, `latestVersion` | As of 2026-09-01. Verify in the Intune console before every release. No version is recorded yet |
| `asr-rules.json` | `Ref.Asr` | `id`, `name`, `recommended` | As of 2026-09-01. Verify against Microsoft guidance before every release. Empty |
| `app-versions.json` | `Ref.AppVersions` | `app`, `latest`, `frequentlyUpdated` | Read by APP-006, which evaluates, and APP-007, which waits on discovered apps. The `app` value is matched against the name a package carries rather than compared with it, so a row for `7-Zip` answers for `7-Zip 26.02 (MSI-x64)`, and the longest matching row wins. Consider generating from winget package manifests rather than by hand. Empty |
| `patterns.json` | `Ref.Patterns` | `name`, `pattern`, and `description` for a person | Regular expressions for script content scanning and for recognising a packaging product in the application list. Deliberately conservative; a false positive is reviewed by a person and the matched text never reaches the report. `name` is the group a rule asks for, `secrets`, `insecureDownload` or `packager` |
| `roles.json` | `Ref.Roles` | `name`, `privileged` | Which Entra directory roles the pack treats as privileged. A judgement about blast radius rather than anything Microsoft publishes as a list |
| `approval.json` | `Ref.Approval` | `operation`, `highImpact` | Operations the pack expects multi-admin approval to cover. The names are the ones the collector normalises an access policy's `policyType` to, so a change here is only useful alongside one there |
| `platforms.json` | `Ref.Platforms` | `platform`, `retired` | Platforms treated as retired for configuration hygiene |
| `deprecated-settings.json` | `Ref.DeprecatedSettings` | `setting`, `replacement` | As of 2026-09-01. Settings Microsoft has deprecated, with their replacement where one exists. Empty, so CFG-013 evaluates and raises nothing |
| `settings-catalog-equivalents.json` | `Ref.SettingsCatalog` | `kind` (`template` or `omaUri`), `identifier`, `equivalent` | As of 2026-09-01. Legacy templates and OMA-URIs the Settings Catalog now covers. Empty, so CFG-007 and CFG-008 evaluate and raise nothing |

## Tables whose accessor is not written yet

Read today through `Ref.Table("<name>")`. The rules that name a compiled accessor for these are skipped until it exists.

| File | Accessor the rules ask for | Columns | Maintenance |
|---|---|---|---|
| `asr-exclusions.json` | `Ref.Asr.BroadExclusions`, `.HasBroadExclusion` | `pattern` | Exclusion patterns treated as broad. Split from `asr-rules.json`, which holds rows of a different kind |
| `defender.json` | `Ref.Defender.IsWeakCloudLevel` | `level`, `weak` | Defender cloud block levels considered weak |
| `defender-exclusions.json` | `Ref.Defender.BroadExclusions`, `.HasBroadExclusion` | `pattern` | Exclusion patterns treated as broad |
| `encryption.json` | `Ref.Encryption.IsWeak` | `method`, `weak` | Encryption methods weaker than current guidance |
| `office.json` | `Ref.Office.IsSlowChannel` | `channel`, `slow` | Microsoft 365 Apps channels considered slow for security updates |
| `naming.json` | `Ref.Naming.Convention` | `name`, `convention` | The convention HYG-012 tests against. Ships permissive; a customer sets their own through overrides |
| `mdm-defaults.json` | `Ref.MdmDefaults.UrlsMatch` | `setting`, `url` | As of 2026-09-01. The default Intune mobility URLs; verify in the Entra portal before every release |
| `esp-app-combinations.json` | `Ref.EspAppCombinations.HasRiskyMix`, `.Describe` | `combination` (a list), `risky` | As of 2026-09-01. Application type combinations known to stall the Enrollment Status Page; verify against current Microsoft guidance before every release |
| `frameworks.json` | none; read through `Ref.Table` | `id`, `name`, `publisher`, `version`, `controls` (a list) | Reference by scheme name, identifier and version only. Never reproduce a framework's published wording; every message in this pack is the vendor's own text |
